# ZID UI

Estrutura inicial da UI alternativa do pfSense (porta 8444).

## Estrutura
- index.php
- app/
- pages/
- api/
- assets/
