(function () {
  if (!window.ZID_UI) {
    window.ZID_UI = {};
  }
})();
