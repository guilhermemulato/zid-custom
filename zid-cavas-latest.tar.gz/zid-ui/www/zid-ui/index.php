<?php
require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/router.php';

zid_ui_route_request();
